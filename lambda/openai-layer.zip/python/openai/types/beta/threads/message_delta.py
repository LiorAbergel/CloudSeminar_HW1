# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from ...._models import BaseModel
from .message_content_delta import MessageContentDelta

__all__ = ["MessageDelta"]


class MessageDelta(BaseModel):
    """The delta containing the fields that have changed on the Message."""

    content: Optional[List[MessageContentDelta]] = None
    """The content of the message in array of text and/or images."""

    role: Optional[Literal["user", "assistant"]] = None
    """The entity that produced the message. One of `user` or `assistant`."""
