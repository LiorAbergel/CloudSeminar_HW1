# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ...._models import BaseModel

__all__ = ["FilePathAnnotation", "FilePath"]


class FilePath(BaseModel):
    file_id: str
    """The ID of the file that was generated."""


class FilePathAnnotation(BaseModel):
    """
    A URL for the file that's generated when the assistant used the `code_interpreter` tool to generate a file.
    """

    end_index: int

    file_path: FilePath

    start_index: int

    text: str
    """The text in the message content that needs to be replaced."""

    type: Literal["file_path"]
    """Always `file_path`."""
