# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from ...._models import BaseModel

__all__ = ["FileCitationDeltaAnnotation", "FileCitation"]


class FileCitation(BaseModel):
    file_id: Optional[str] = None
    """The ID of the specific File the citation is from."""

    quote: Optional[str] = None
    """The specific quote in the file."""


class FileCitationDeltaAnnotation(BaseModel):
    """
    A citation within the message that points to a specific quote from a specific File associated with the assistant or the message. Generated when the assistant uses the "file_search" tool to search files.
    """

    index: int
    """The index of the annotation in the text content part."""

    type: Literal["file_citation"]
    """Always `file_citation`."""

    end_index: Optional[int] = None

    file_citation: Optional[FileCitation] = None

    start_index: Optional[int] = None

    text: Optional[str] = None
    """The text in the message content that needs to be replaced."""
