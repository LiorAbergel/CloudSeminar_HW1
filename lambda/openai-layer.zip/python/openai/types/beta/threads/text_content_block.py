# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from .text import Text
from ...._models import BaseModel

__all__ = ["TextContentBlock"]


class TextContentBlock(BaseModel):
    """The text content that is part of a message."""

    text: Text

    type: Literal["text"]
    """Always `text`."""
