# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

import typing_extensions
from typing import Union, Mapping, Optional, cast
from typing_extensions import Literal, overload

import httpx2

from .. import _legacy_response
from ..types import image_edit_params, image_generate_params, image_create_variation_params
from .._files import deepcopy_with_paths
from .._types import Body, Omit, Query, Headers, NotGiven, FileTypes, SequenceNotStr, omit, not_given
from .._utils import extract_files, required_args, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import to_streamed_response_wrapper, async_to_streamed_response_wrapper
from .._streaming import Stream, AsyncStream
from .._base_client import make_request_options
from ..types.image_model import ImageModel
from ..types.images_response import ImagesResponse
from ..types.image_gen_stream_event import ImageGenStreamEvent
from ..types.image_edit_stream_event import ImageEditStreamEvent

__all__ = ["Images", "AsyncImages"]


class Images(SyncAPIResource):
    """Given a prompt and/or an input image, the model will generate a new image."""

    @cached_property
    def with_raw_response(self) -> ImagesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/openai/openai-python#accessing-raw-response-data-eg-headers
        """
        return ImagesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ImagesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/openai/openai-python#with_streaming_response
        """
        return ImagesWithStreamingResponse(self)

    @typing_extensions.deprecated("deprecated")
    def create_variation(
        self,
        *,
        image: FileTypes,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        size: Optional[Literal["256x256", "512x512", "1024x1024"]] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse:
        """This endpoint is retired and no longer available.

        Use the image edits endpoint
        with a GPT Image model and a prompt to create a variation of an image. The
        request and response schemas below describe the legacy contract.

        Args:
          image: The image to use as the basis for the variation(s). Must be a valid PNG file,
              less than 4MB, and square.

          model: The legacy model used by the retired image variations endpoint. This endpoint no
              longer accepts requests.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          n: The number of images to generate. Must be between 1 and 10.

          response_format: The format in which the generated images are returned. Must be one of `url` or
              `b64_json`. URLs are only valid for 60 minutes after the image has been
              generated.

          size: The size of the generated images. Must be one of `256x256`, `512x512`, or
              `1024x1024`.

          user: A unique identifier representing your end-user, which can help OpenAI to monitor
              and detect abuse.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_with_paths(
            {
                "image": image,
                "model": model,
                "n": n,
                "response_format": response_format,
                "size": size,
                "user": user,
            },
            [["image"]],
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["image"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return self._post(
            "/images/variations",
            body=maybe_transform(body, image_create_variation_params.ImageCreateVariationParams),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                security={"bearer_auth": True},
            ),
            cast_to=ImagesResponse,
        )

    @overload
    def edit(
        self,
        *,
        image: Union[FileTypes, SequenceNotStr[FileTypes]],
        prompt: str,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        input_fidelity: Optional[Literal["high", "low"]] | Omit = omit,
        markup: FileTypes | Omit = omit,
        mask: FileTypes | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[str, Literal["1024x1024", "1536x1024", "1024x1536", "auto", "256x256", "512x512"], None]
        | Omit = omit,
        stream: Optional[Literal[False]] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse:
        """Creates an edited or extended image given one or more source images and a
        prompt.

        This endpoint supports GPT Image models.

        Args:
          image: The image(s) to edit. Must be a supported image file or an array of images.

              For the GPT image models (`gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`), each image should be a `png`, `webp`, or
              `jpg` file less than 50MB. You can provide up to 16 images.
              `chatgpt-image-latest` follows the same input constraints as GPT image models.

          prompt: A text description of the desired image(s). The maximum length is 32000
              characters for the GPT image models.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          input_fidelity: Control how much effort the model will exert to match the style and features,
              especially facial features, of input images. Supports `high` and `low` on
              `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit
              this parameter. Defaults to `low` on supported models.

          markup: A transparent PNG overlaid on the first image to guide the edit. Must match that
              image's dimensions after orientation and contain transparent pixels. Supports
              GPT Image 2.5. Cannot be combined with mask.

          mask: An additional image whose fully transparent areas (e.g. where alpha is zero)
              indicate where `image` should be edited. If there are multiple images provided,
              the mask will be applied on the first image. Must be a valid PNG file, less than
              4MB, and have the same dimensions as `image`.

          model: The GPT image model to use for image editing (`gpt-image-1-mini`,
              `gpt-image-1.5`, `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, `gpt-image-2.5-flare-2026-09-08`,
              `gpt-image-2.6-sunburst`, `gpt-image-2.6-flare`, or `chatgpt-image-latest`).

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models. The default value is `png`.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated for GPT image models. The GPT
              image models support `low`, `medium`, and `high`. `gpt-image-2.5-sunburst` and
              `gpt-image-2.5-flare`, including their `2026-09-08` snapshots, also support
              `xhigh` and `max`. Defaults to `auto`.

              Deprecated values:

              - "standard": This quality was only supported by retired DALL·E models. Use a
                GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. Defaults to `auto`. For `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as
              `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be
              divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1.
              Resolutions above `2560x1440` are experimental, and the maximum supported
              resolution is `3840x2160`. The requested size must also satisfy the model's
              current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and
              `1024x1536` are supported by the GPT image models; `auto` is supported for
              models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512": This legacy size suggestion is retained for SDK
                compatibility. Check the selected GPT image model's supported sizes.

          stream: Edit the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    def edit(
        self,
        *,
        image: Union[FileTypes, SequenceNotStr[FileTypes]],
        prompt: str,
        stream: Literal[True],
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        input_fidelity: Optional[Literal["high", "low"]] | Omit = omit,
        markup: FileTypes | Omit = omit,
        mask: FileTypes | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[str, Literal["1024x1024", "1536x1024", "1024x1536", "auto", "256x256", "512x512"], None]
        | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> Stream[ImageEditStreamEvent]:
        """Creates an edited or extended image given one or more source images and a
        prompt.

        This endpoint supports GPT Image models.

        Args:
          image: The image(s) to edit. Must be a supported image file or an array of images.

              For the GPT image models (`gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`), each image should be a `png`, `webp`, or
              `jpg` file less than 50MB. You can provide up to 16 images.
              `chatgpt-image-latest` follows the same input constraints as GPT image models.

          prompt: A text description of the desired image(s). The maximum length is 32000
              characters for the GPT image models.

          stream: Edit the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          input_fidelity: Control how much effort the model will exert to match the style and features,
              especially facial features, of input images. Supports `high` and `low` on
              `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit
              this parameter. Defaults to `low` on supported models.

          markup: A transparent PNG overlaid on the first image to guide the edit. Must match that
              image's dimensions after orientation and contain transparent pixels. Supports
              GPT Image 2.5. Cannot be combined with mask.

          mask: An additional image whose fully transparent areas (e.g. where alpha is zero)
              indicate where `image` should be edited. If there are multiple images provided,
              the mask will be applied on the first image. Must be a valid PNG file, less than
              4MB, and have the same dimensions as `image`.

          model: The GPT image model to use for image editing (`gpt-image-1-mini`,
              `gpt-image-1.5`, `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, `gpt-image-2.5-flare-2026-09-08`,
              `gpt-image-2.6-sunburst`, `gpt-image-2.6-flare`, or `chatgpt-image-latest`).

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models. The default value is `png`.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated for GPT image models. The GPT
              image models support `low`, `medium`, and `high`. `gpt-image-2.5-sunburst` and
              `gpt-image-2.5-flare`, including their `2026-09-08` snapshots, also support
              `xhigh` and `max`. Defaults to `auto`.

              Deprecated values:

              - "standard": This quality was only supported by retired DALL·E models. Use a
                GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. Defaults to `auto`. For `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as
              `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be
              divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1.
              Resolutions above `2560x1440` are experimental, and the maximum supported
              resolution is `3840x2160`. The requested size must also satisfy the model's
              current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and
              `1024x1536` are supported by the GPT image models; `auto` is supported for
              models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512": This legacy size suggestion is retained for SDK
                compatibility. Check the selected GPT image model's supported sizes.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    def edit(
        self,
        *,
        image: Union[FileTypes, SequenceNotStr[FileTypes]],
        prompt: str,
        stream: bool,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        input_fidelity: Optional[Literal["high", "low"]] | Omit = omit,
        markup: FileTypes | Omit = omit,
        mask: FileTypes | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[str, Literal["1024x1024", "1536x1024", "1024x1536", "auto", "256x256", "512x512"], None]
        | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse | Stream[ImageEditStreamEvent]:
        """Creates an edited or extended image given one or more source images and a
        prompt.

        This endpoint supports GPT Image models.

        Args:
          image: The image(s) to edit. Must be a supported image file or an array of images.

              For the GPT image models (`gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`), each image should be a `png`, `webp`, or
              `jpg` file less than 50MB. You can provide up to 16 images.
              `chatgpt-image-latest` follows the same input constraints as GPT image models.

          prompt: A text description of the desired image(s). The maximum length is 32000
              characters for the GPT image models.

          stream: Edit the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          input_fidelity: Control how much effort the model will exert to match the style and features,
              especially facial features, of input images. Supports `high` and `low` on
              `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit
              this parameter. Defaults to `low` on supported models.

          markup: A transparent PNG overlaid on the first image to guide the edit. Must match that
              image's dimensions after orientation and contain transparent pixels. Supports
              GPT Image 2.5. Cannot be combined with mask.

          mask: An additional image whose fully transparent areas (e.g. where alpha is zero)
              indicate where `image` should be edited. If there are multiple images provided,
              the mask will be applied on the first image. Must be a valid PNG file, less than
              4MB, and have the same dimensions as `image`.

          model: The GPT image model to use for image editing (`gpt-image-1-mini`,
              `gpt-image-1.5`, `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, `gpt-image-2.5-flare-2026-09-08`,
              `gpt-image-2.6-sunburst`, `gpt-image-2.6-flare`, or `chatgpt-image-latest`).

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models. The default value is `png`.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated for GPT image models. The GPT
              image models support `low`, `medium`, and `high`. `gpt-image-2.5-sunburst` and
              `gpt-image-2.5-flare`, including their `2026-09-08` snapshots, also support
              `xhigh` and `max`. Defaults to `auto`.

              Deprecated values:

              - "standard": This quality was only supported by retired DALL·E models. Use a
                GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. Defaults to `auto`. For `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as
              `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be
              divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1.
              Resolutions above `2560x1440` are experimental, and the maximum supported
              resolution is `3840x2160`. The requested size must also satisfy the model's
              current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and
              `1024x1536` are supported by the GPT image models; `auto` is supported for
              models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512": This legacy size suggestion is retained for SDK
                compatibility. Check the selected GPT image model's supported sizes.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(["image", "prompt"], ["image", "prompt", "stream"])
    def edit(
        self,
        *,
        image: Union[FileTypes, SequenceNotStr[FileTypes]],
        prompt: str,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        input_fidelity: Optional[Literal["high", "low"]] | Omit = omit,
        markup: FileTypes | Omit = omit,
        mask: FileTypes | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[str, Literal["1024x1024", "1536x1024", "1024x1536", "auto", "256x256", "512x512"], None]
        | Omit = omit,
        stream: Optional[Literal[False]] | Literal[True] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse | Stream[ImageEditStreamEvent]:
        body = deepcopy_with_paths(
            {
                "image": image,
                "prompt": prompt,
                "background": background,
                "complexity": complexity,
                "frame_count": frame_count,
                "frame_duration_ms": frame_duration_ms,
                "input_fidelity": input_fidelity,
                "markup": markup,
                "mask": mask,
                "model": model,
                "n": n,
                "output_compression": output_compression,
                "output_format": output_format,
                "partial_images": partial_images,
                "quality": quality,
                "response_format": response_format,
                "safety_identifier": safety_identifier,
                "size": size,
                "stream": stream,
                "user": user,
            },
            [["image"], ["image", "<array>"], ["markup"], ["mask"]],
        )
        files = extract_files(
            cast(Mapping[str, object], body), paths=[["image"], ["image", "<array>"], ["markup"], ["mask"]]
        )
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return self._post(
            "/images/edits",
            body=maybe_transform(
                body,
                image_edit_params.ImageEditParamsStreaming if stream else image_edit_params.ImageEditParamsNonStreaming,
            ),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                security={"bearer_auth": True},
            ),
            cast_to=ImagesResponse,
            stream=stream or False,
            stream_cls=Stream[ImageEditStreamEvent],
        )

    @overload
    def generate(
        self,
        *,
        prompt: str,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        moderation: Optional[Literal["low", "auto"]] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif", "svg"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard", "hd"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[
            str,
            Literal["auto", "1024x1024", "1536x1024", "1024x1536", "256x256", "512x512", "1792x1024", "1024x1792"],
            None,
        ]
        | Omit = omit,
        stream: Optional[Literal[False]] | Omit = omit,
        style: Optional[Literal["vivid", "natural"]] | Omit = omit,
        svg: Optional[image_generate_params.Svg] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse:
        """
        Creates an image given a prompt using a GPT Image model.
        [Learn more](https://developers.openai.com/api/docs/guides/images-vision).

        Args:
          prompt: A text description of the desired image(s). The maximum length is 32000
              characters.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          model: The GPT image model to use for image generation. Specify a model explicitly.
              Supported models include `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, `gpt-image-2.6-sunburst`,
              `gpt-image-2.6-flare`, and `chatgpt-image-latest`.

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          moderation: Control the content-moderation level for images generated by the GPT image
              models. Must be either `low` for less restrictive filtering or `auto` (default
              value).

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated.

              - `auto` (default value) will automatically select the best quality for the
                given model.
              - `high`, `medium` and `low` are supported for the GPT image models.
              - `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their
                `2026-09-08` snapshots, also support `xhigh` and `max`.

              Deprecated values:

              - "standard", "hd": This quality was only supported by retired DALL·E models.
                Use a GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary
              resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`.
              Width and height must both be divisible by 16 and the requested aspect ratio
              must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and
              the maximum supported resolution is `3840x2160`. The requested size must also
              satisfy the model's current pixel and edge limits. The standard sizes
              `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models;
              `auto` is supported for models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512", "1792x1024", "1024x1792": This legacy size suggestion is
                retained for SDK compatibility. Check the selected GPT image model's supported
                sizes.

          stream: Generate the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information. This parameter is only supported for the GPT image models.

          style: Legacy style parameter for retired image models. Unsupported for GPT image
              models; describe the desired style in the prompt instead.

          svg: Selects the model and reasoning effort used to author SVG output. Requires
              output_format=svg and access to SVG model selection. When model selection is
              enabled, supply svg.model. When model selection is disabled, omit this object.
              The top-level model selects the image model that creates the reference image.
              SVG generation requires n=1 and does not support streaming, partial images,
              prompt_rewriter, or output_compression. SVG edits are not supported.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    def generate(
        self,
        *,
        prompt: str,
        stream: Literal[True],
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        moderation: Optional[Literal["low", "auto"]] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif", "svg"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard", "hd"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[
            str,
            Literal["auto", "1024x1024", "1536x1024", "1024x1536", "256x256", "512x512", "1792x1024", "1024x1792"],
            None,
        ]
        | Omit = omit,
        style: Optional[Literal["vivid", "natural"]] | Omit = omit,
        svg: Optional[image_generate_params.Svg] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> Stream[ImageGenStreamEvent]:
        """
        Creates an image given a prompt using a GPT Image model.
        [Learn more](https://developers.openai.com/api/docs/guides/images-vision).

        Args:
          prompt: A text description of the desired image(s). The maximum length is 32000
              characters.

          stream: Generate the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information. This parameter is only supported for the GPT image models.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          model: The GPT image model to use for image generation. Specify a model explicitly.
              Supported models include `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, `gpt-image-2.6-sunburst`,
              `gpt-image-2.6-flare`, and `chatgpt-image-latest`.

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          moderation: Control the content-moderation level for images generated by the GPT image
              models. Must be either `low` for less restrictive filtering or `auto` (default
              value).

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated.

              - `auto` (default value) will automatically select the best quality for the
                given model.
              - `high`, `medium` and `low` are supported for the GPT image models.
              - `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their
                `2026-09-08` snapshots, also support `xhigh` and `max`.

              Deprecated values:

              - "standard", "hd": This quality was only supported by retired DALL·E models.
                Use a GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary
              resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`.
              Width and height must both be divisible by 16 and the requested aspect ratio
              must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and
              the maximum supported resolution is `3840x2160`. The requested size must also
              satisfy the model's current pixel and edge limits. The standard sizes
              `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models;
              `auto` is supported for models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512", "1792x1024", "1024x1792": This legacy size suggestion is
                retained for SDK compatibility. Check the selected GPT image model's supported
                sizes.

          style: Legacy style parameter for retired image models. Unsupported for GPT image
              models; describe the desired style in the prompt instead.

          svg: Selects the model and reasoning effort used to author SVG output. Requires
              output_format=svg and access to SVG model selection. When model selection is
              enabled, supply svg.model. When model selection is disabled, omit this object.
              The top-level model selects the image model that creates the reference image.
              SVG generation requires n=1 and does not support streaming, partial images,
              prompt_rewriter, or output_compression. SVG edits are not supported.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    def generate(
        self,
        *,
        prompt: str,
        stream: bool,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        moderation: Optional[Literal["low", "auto"]] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif", "svg"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard", "hd"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[
            str,
            Literal["auto", "1024x1024", "1536x1024", "1024x1536", "256x256", "512x512", "1792x1024", "1024x1792"],
            None,
        ]
        | Omit = omit,
        style: Optional[Literal["vivid", "natural"]] | Omit = omit,
        svg: Optional[image_generate_params.Svg] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse | Stream[ImageGenStreamEvent]:
        """
        Creates an image given a prompt using a GPT Image model.
        [Learn more](https://developers.openai.com/api/docs/guides/images-vision).

        Args:
          prompt: A text description of the desired image(s). The maximum length is 32000
              characters.

          stream: Generate the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information. This parameter is only supported for the GPT image models.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          model: The GPT image model to use for image generation. Specify a model explicitly.
              Supported models include `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, `gpt-image-2.6-sunburst`,
              `gpt-image-2.6-flare`, and `chatgpt-image-latest`.

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          moderation: Control the content-moderation level for images generated by the GPT image
              models. Must be either `low` for less restrictive filtering or `auto` (default
              value).

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated.

              - `auto` (default value) will automatically select the best quality for the
                given model.
              - `high`, `medium` and `low` are supported for the GPT image models.
              - `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their
                `2026-09-08` snapshots, also support `xhigh` and `max`.

              Deprecated values:

              - "standard", "hd": This quality was only supported by retired DALL·E models.
                Use a GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary
              resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`.
              Width and height must both be divisible by 16 and the requested aspect ratio
              must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and
              the maximum supported resolution is `3840x2160`. The requested size must also
              satisfy the model's current pixel and edge limits. The standard sizes
              `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models;
              `auto` is supported for models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512", "1792x1024", "1024x1792": This legacy size suggestion is
                retained for SDK compatibility. Check the selected GPT image model's supported
                sizes.

          style: Legacy style parameter for retired image models. Unsupported for GPT image
              models; describe the desired style in the prompt instead.

          svg: Selects the model and reasoning effort used to author SVG output. Requires
              output_format=svg and access to SVG model selection. When model selection is
              enabled, supply svg.model. When model selection is disabled, omit this object.
              The top-level model selects the image model that creates the reference image.
              SVG generation requires n=1 and does not support streaming, partial images,
              prompt_rewriter, or output_compression. SVG edits are not supported.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(["prompt"], ["prompt", "stream"])
    def generate(
        self,
        *,
        prompt: str,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        moderation: Optional[Literal["low", "auto"]] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif", "svg"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard", "hd"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[
            str,
            Literal["auto", "1024x1024", "1536x1024", "1024x1536", "256x256", "512x512", "1792x1024", "1024x1792"],
            None,
        ]
        | Omit = omit,
        stream: Optional[Literal[False]] | Literal[True] | Omit = omit,
        style: Optional[Literal["vivid", "natural"]] | Omit = omit,
        svg: Optional[image_generate_params.Svg] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse | Stream[ImageGenStreamEvent]:
        return self._post(
            "/images/generations",
            body=maybe_transform(
                {
                    "model": model,
                    "stream": stream,
                    "prompt": prompt,
                    "background": background,
                    "complexity": complexity,
                    "frame_count": frame_count,
                    "frame_duration_ms": frame_duration_ms,
                    "moderation": moderation,
                    "n": n,
                    "output_compression": output_compression,
                    "output_format": output_format,
                    "partial_images": partial_images,
                    "quality": quality,
                    "response_format": response_format,
                    "safety_identifier": safety_identifier,
                    "size": size,
                    "style": style,
                    "svg": svg,
                    "user": user,
                },
                image_generate_params.ImageGenerateParamsStreaming
                if stream
                else image_generate_params.ImageGenerateParamsNonStreaming,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                security={"bearer_auth": True},
            ),
            cast_to=ImagesResponse,
            stream=stream or False,
            stream_cls=Stream[ImageGenStreamEvent],
        )


class AsyncImages(AsyncAPIResource):
    """Given a prompt and/or an input image, the model will generate a new image."""

    @cached_property
    def with_raw_response(self) -> AsyncImagesWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/openai/openai-python#accessing-raw-response-data-eg-headers
        """
        return AsyncImagesWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncImagesWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/openai/openai-python#with_streaming_response
        """
        return AsyncImagesWithStreamingResponse(self)

    @typing_extensions.deprecated("deprecated")
    async def create_variation(
        self,
        *,
        image: FileTypes,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        size: Optional[Literal["256x256", "512x512", "1024x1024"]] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse:
        """This endpoint is retired and no longer available.

        Use the image edits endpoint
        with a GPT Image model and a prompt to create a variation of an image. The
        request and response schemas below describe the legacy contract.

        Args:
          image: The image to use as the basis for the variation(s). Must be a valid PNG file,
              less than 4MB, and square.

          model: The legacy model used by the retired image variations endpoint. This endpoint no
              longer accepts requests.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          n: The number of images to generate. Must be between 1 and 10.

          response_format: The format in which the generated images are returned. Must be one of `url` or
              `b64_json`. URLs are only valid for 60 minutes after the image has been
              generated.

          size: The size of the generated images. Must be one of `256x256`, `512x512`, or
              `1024x1024`.

          user: A unique identifier representing your end-user, which can help OpenAI to monitor
              and detect abuse.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        body = deepcopy_with_paths(
            {
                "image": image,
                "model": model,
                "n": n,
                "response_format": response_format,
                "size": size,
                "user": user,
            },
            [["image"]],
        )
        files = extract_files(cast(Mapping[str, object], body), paths=[["image"]])
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return await self._post(
            "/images/variations",
            body=await async_maybe_transform(body, image_create_variation_params.ImageCreateVariationParams),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                security={"bearer_auth": True},
            ),
            cast_to=ImagesResponse,
        )

    @overload
    async def edit(
        self,
        *,
        image: Union[FileTypes, SequenceNotStr[FileTypes]],
        prompt: str,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        input_fidelity: Optional[Literal["high", "low"]] | Omit = omit,
        markup: FileTypes | Omit = omit,
        mask: FileTypes | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[str, Literal["1024x1024", "1536x1024", "1024x1536", "auto", "256x256", "512x512"], None]
        | Omit = omit,
        stream: Optional[Literal[False]] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse:
        """Creates an edited or extended image given one or more source images and a
        prompt.

        This endpoint supports GPT Image models.

        Args:
          image: The image(s) to edit. Must be a supported image file or an array of images.

              For the GPT image models (`gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`), each image should be a `png`, `webp`, or
              `jpg` file less than 50MB. You can provide up to 16 images.
              `chatgpt-image-latest` follows the same input constraints as GPT image models.

          prompt: A text description of the desired image(s). The maximum length is 32000
              characters for the GPT image models.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          input_fidelity: Control how much effort the model will exert to match the style and features,
              especially facial features, of input images. Supports `high` and `low` on
              `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit
              this parameter. Defaults to `low` on supported models.

          markup: A transparent PNG overlaid on the first image to guide the edit. Must match that
              image's dimensions after orientation and contain transparent pixels. Supports
              GPT Image 2.5. Cannot be combined with mask.

          mask: An additional image whose fully transparent areas (e.g. where alpha is zero)
              indicate where `image` should be edited. If there are multiple images provided,
              the mask will be applied on the first image. Must be a valid PNG file, less than
              4MB, and have the same dimensions as `image`.

          model: The GPT image model to use for image editing (`gpt-image-1-mini`,
              `gpt-image-1.5`, `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, `gpt-image-2.5-flare-2026-09-08`,
              `gpt-image-2.6-sunburst`, `gpt-image-2.6-flare`, or `chatgpt-image-latest`).

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models. The default value is `png`.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated for GPT image models. The GPT
              image models support `low`, `medium`, and `high`. `gpt-image-2.5-sunburst` and
              `gpt-image-2.5-flare`, including their `2026-09-08` snapshots, also support
              `xhigh` and `max`. Defaults to `auto`.

              Deprecated values:

              - "standard": This quality was only supported by retired DALL·E models. Use a
                GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. Defaults to `auto`. For `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as
              `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be
              divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1.
              Resolutions above `2560x1440` are experimental, and the maximum supported
              resolution is `3840x2160`. The requested size must also satisfy the model's
              current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and
              `1024x1536` are supported by the GPT image models; `auto` is supported for
              models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512": This legacy size suggestion is retained for SDK
                compatibility. Check the selected GPT image model's supported sizes.

          stream: Edit the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    async def edit(
        self,
        *,
        image: Union[FileTypes, SequenceNotStr[FileTypes]],
        prompt: str,
        stream: Literal[True],
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        input_fidelity: Optional[Literal["high", "low"]] | Omit = omit,
        markup: FileTypes | Omit = omit,
        mask: FileTypes | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[str, Literal["1024x1024", "1536x1024", "1024x1536", "auto", "256x256", "512x512"], None]
        | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[ImageEditStreamEvent]:
        """Creates an edited or extended image given one or more source images and a
        prompt.

        This endpoint supports GPT Image models.

        Args:
          image: The image(s) to edit. Must be a supported image file or an array of images.

              For the GPT image models (`gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`), each image should be a `png`, `webp`, or
              `jpg` file less than 50MB. You can provide up to 16 images.
              `chatgpt-image-latest` follows the same input constraints as GPT image models.

          prompt: A text description of the desired image(s). The maximum length is 32000
              characters for the GPT image models.

          stream: Edit the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          input_fidelity: Control how much effort the model will exert to match the style and features,
              especially facial features, of input images. Supports `high` and `low` on
              `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit
              this parameter. Defaults to `low` on supported models.

          markup: A transparent PNG overlaid on the first image to guide the edit. Must match that
              image's dimensions after orientation and contain transparent pixels. Supports
              GPT Image 2.5. Cannot be combined with mask.

          mask: An additional image whose fully transparent areas (e.g. where alpha is zero)
              indicate where `image` should be edited. If there are multiple images provided,
              the mask will be applied on the first image. Must be a valid PNG file, less than
              4MB, and have the same dimensions as `image`.

          model: The GPT image model to use for image editing (`gpt-image-1-mini`,
              `gpt-image-1.5`, `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, `gpt-image-2.5-flare-2026-09-08`,
              `gpt-image-2.6-sunburst`, `gpt-image-2.6-flare`, or `chatgpt-image-latest`).

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models. The default value is `png`.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated for GPT image models. The GPT
              image models support `low`, `medium`, and `high`. `gpt-image-2.5-sunburst` and
              `gpt-image-2.5-flare`, including their `2026-09-08` snapshots, also support
              `xhigh` and `max`. Defaults to `auto`.

              Deprecated values:

              - "standard": This quality was only supported by retired DALL·E models. Use a
                GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. Defaults to `auto`. For `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as
              `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be
              divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1.
              Resolutions above `2560x1440` are experimental, and the maximum supported
              resolution is `3840x2160`. The requested size must also satisfy the model's
              current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and
              `1024x1536` are supported by the GPT image models; `auto` is supported for
              models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512": This legacy size suggestion is retained for SDK
                compatibility. Check the selected GPT image model's supported sizes.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    async def edit(
        self,
        *,
        image: Union[FileTypes, SequenceNotStr[FileTypes]],
        prompt: str,
        stream: bool,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        input_fidelity: Optional[Literal["high", "low"]] | Omit = omit,
        markup: FileTypes | Omit = omit,
        mask: FileTypes | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[str, Literal["1024x1024", "1536x1024", "1024x1536", "auto", "256x256", "512x512"], None]
        | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse | AsyncStream[ImageEditStreamEvent]:
        """Creates an edited or extended image given one or more source images and a
        prompt.

        This endpoint supports GPT Image models.

        Args:
          image: The image(s) to edit. Must be a supported image file or an array of images.

              For the GPT image models (`gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`), each image should be a `png`, `webp`, or
              `jpg` file less than 50MB. You can provide up to 16 images.
              `chatgpt-image-latest` follows the same input constraints as GPT image models.

          prompt: A text description of the desired image(s). The maximum length is 32000
              characters for the GPT image models.

          stream: Edit the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          input_fidelity: Control how much effort the model will exert to match the style and features,
              especially facial features, of input images. Supports `high` and `low` on
              `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit
              this parameter. Defaults to `low` on supported models.

          markup: A transparent PNG overlaid on the first image to guide the edit. Must match that
              image's dimensions after orientation and contain transparent pixels. Supports
              GPT Image 2.5. Cannot be combined with mask.

          mask: An additional image whose fully transparent areas (e.g. where alpha is zero)
              indicate where `image` should be edited. If there are multiple images provided,
              the mask will be applied on the first image. Must be a valid PNG file, less than
              4MB, and have the same dimensions as `image`.

          model: The GPT image model to use for image editing (`gpt-image-1-mini`,
              `gpt-image-1.5`, `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, `gpt-image-2.5-flare-2026-09-08`,
              `gpt-image-2.6-sunburst`, `gpt-image-2.6-flare`, or `chatgpt-image-latest`).

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models. The default value is `png`.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated for GPT image models. The GPT
              image models support `low`, `medium`, and `high`. `gpt-image-2.5-sunburst` and
              `gpt-image-2.5-flare`, including their `2026-09-08` snapshots, also support
              `xhigh` and `max`. Defaults to `auto`.

              Deprecated values:

              - "standard": This quality was only supported by retired DALL·E models. Use a
                GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. Defaults to `auto`. For `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
              `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as
              `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be
              divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1.
              Resolutions above `2560x1440` are experimental, and the maximum supported
              resolution is `3840x2160`. The requested size must also satisfy the model's
              current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and
              `1024x1536` are supported by the GPT image models; `auto` is supported for
              models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512": This legacy size suggestion is retained for SDK
                compatibility. Check the selected GPT image model's supported sizes.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(["image", "prompt"], ["image", "prompt", "stream"])
    async def edit(
        self,
        *,
        image: Union[FileTypes, SequenceNotStr[FileTypes]],
        prompt: str,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        input_fidelity: Optional[Literal["high", "low"]] | Omit = omit,
        markup: FileTypes | Omit = omit,
        mask: FileTypes | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[str, Literal["1024x1024", "1536x1024", "1024x1536", "auto", "256x256", "512x512"], None]
        | Omit = omit,
        stream: Optional[Literal[False]] | Literal[True] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse | AsyncStream[ImageEditStreamEvent]:
        body = deepcopy_with_paths(
            {
                "image": image,
                "prompt": prompt,
                "background": background,
                "complexity": complexity,
                "frame_count": frame_count,
                "frame_duration_ms": frame_duration_ms,
                "input_fidelity": input_fidelity,
                "markup": markup,
                "mask": mask,
                "model": model,
                "n": n,
                "output_compression": output_compression,
                "output_format": output_format,
                "partial_images": partial_images,
                "quality": quality,
                "response_format": response_format,
                "safety_identifier": safety_identifier,
                "size": size,
                "stream": stream,
                "user": user,
            },
            [["image"], ["image", "<array>"], ["markup"], ["mask"]],
        )
        files = extract_files(
            cast(Mapping[str, object], body), paths=[["image"], ["image", "<array>"], ["markup"], ["mask"]]
        )
        # It should be noted that the actual Content-Type header that will be
        # sent to the server will contain a `boundary` parameter, e.g.
        # multipart/form-data; boundary=---abc--
        extra_headers = {"Content-Type": "multipart/form-data", **(extra_headers or {})}
        return await self._post(
            "/images/edits",
            body=await async_maybe_transform(
                body,
                image_edit_params.ImageEditParamsStreaming if stream else image_edit_params.ImageEditParamsNonStreaming,
            ),
            files=files,
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                security={"bearer_auth": True},
            ),
            cast_to=ImagesResponse,
            stream=stream or False,
            stream_cls=AsyncStream[ImageEditStreamEvent],
        )

    @overload
    async def generate(
        self,
        *,
        prompt: str,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        moderation: Optional[Literal["low", "auto"]] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif", "svg"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard", "hd"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[
            str,
            Literal["auto", "1024x1024", "1536x1024", "1024x1536", "256x256", "512x512", "1792x1024", "1024x1792"],
            None,
        ]
        | Omit = omit,
        stream: Optional[Literal[False]] | Omit = omit,
        style: Optional[Literal["vivid", "natural"]] | Omit = omit,
        svg: Optional[image_generate_params.Svg] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse:
        """
        Creates an image given a prompt using a GPT Image model.
        [Learn more](https://developers.openai.com/api/docs/guides/images-vision).

        Args:
          prompt: A text description of the desired image(s). The maximum length is 32000
              characters.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          model: The GPT image model to use for image generation. Specify a model explicitly.
              Supported models include `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, `gpt-image-2.6-sunburst`,
              `gpt-image-2.6-flare`, and `chatgpt-image-latest`.

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          moderation: Control the content-moderation level for images generated by the GPT image
              models. Must be either `low` for less restrictive filtering or `auto` (default
              value).

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated.

              - `auto` (default value) will automatically select the best quality for the
                given model.
              - `high`, `medium` and `low` are supported for the GPT image models.
              - `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their
                `2026-09-08` snapshots, also support `xhigh` and `max`.

              Deprecated values:

              - "standard", "hd": This quality was only supported by retired DALL·E models.
                Use a GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary
              resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`.
              Width and height must both be divisible by 16 and the requested aspect ratio
              must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and
              the maximum supported resolution is `3840x2160`. The requested size must also
              satisfy the model's current pixel and edge limits. The standard sizes
              `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models;
              `auto` is supported for models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512", "1792x1024", "1024x1792": This legacy size suggestion is
                retained for SDK compatibility. Check the selected GPT image model's supported
                sizes.

          stream: Generate the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information. This parameter is only supported for the GPT image models.

          style: Legacy style parameter for retired image models. Unsupported for GPT image
              models; describe the desired style in the prompt instead.

          svg: Selects the model and reasoning effort used to author SVG output. Requires
              output_format=svg and access to SVG model selection. When model selection is
              enabled, supply svg.model. When model selection is disabled, omit this object.
              The top-level model selects the image model that creates the reference image.
              SVG generation requires n=1 and does not support streaming, partial images,
              prompt_rewriter, or output_compression. SVG edits are not supported.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    async def generate(
        self,
        *,
        prompt: str,
        stream: Literal[True],
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        moderation: Optional[Literal["low", "auto"]] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif", "svg"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard", "hd"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[
            str,
            Literal["auto", "1024x1024", "1536x1024", "1024x1536", "256x256", "512x512", "1792x1024", "1024x1792"],
            None,
        ]
        | Omit = omit,
        style: Optional[Literal["vivid", "natural"]] | Omit = omit,
        svg: Optional[image_generate_params.Svg] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[ImageGenStreamEvent]:
        """
        Creates an image given a prompt using a GPT Image model.
        [Learn more](https://developers.openai.com/api/docs/guides/images-vision).

        Args:
          prompt: A text description of the desired image(s). The maximum length is 32000
              characters.

          stream: Generate the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information. This parameter is only supported for the GPT image models.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          model: The GPT image model to use for image generation. Specify a model explicitly.
              Supported models include `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, `gpt-image-2.6-sunburst`,
              `gpt-image-2.6-flare`, and `chatgpt-image-latest`.

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          moderation: Control the content-moderation level for images generated by the GPT image
              models. Must be either `low` for less restrictive filtering or `auto` (default
              value).

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated.

              - `auto` (default value) will automatically select the best quality for the
                given model.
              - `high`, `medium` and `low` are supported for the GPT image models.
              - `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their
                `2026-09-08` snapshots, also support `xhigh` and `max`.

              Deprecated values:

              - "standard", "hd": This quality was only supported by retired DALL·E models.
                Use a GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary
              resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`.
              Width and height must both be divisible by 16 and the requested aspect ratio
              must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and
              the maximum supported resolution is `3840x2160`. The requested size must also
              satisfy the model's current pixel and edge limits. The standard sizes
              `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models;
              `auto` is supported for models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512", "1792x1024", "1024x1792": This legacy size suggestion is
                retained for SDK compatibility. Check the selected GPT image model's supported
                sizes.

          style: Legacy style parameter for retired image models. Unsupported for GPT image
              models; describe the desired style in the prompt instead.

          svg: Selects the model and reasoning effort used to author SVG output. Requires
              output_format=svg and access to SVG model selection. When model selection is
              enabled, supply svg.model. When model selection is disabled, omit this object.
              The top-level model selects the image model that creates the reference image.
              SVG generation requires n=1 and does not support streaming, partial images,
              prompt_rewriter, or output_compression. SVG edits are not supported.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @overload
    async def generate(
        self,
        *,
        prompt: str,
        stream: bool,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        moderation: Optional[Literal["low", "auto"]] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif", "svg"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard", "hd"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[
            str,
            Literal["auto", "1024x1024", "1536x1024", "1024x1536", "256x256", "512x512", "1792x1024", "1024x1792"],
            None,
        ]
        | Omit = omit,
        style: Optional[Literal["vivid", "natural"]] | Omit = omit,
        svg: Optional[image_generate_params.Svg] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse | AsyncStream[ImageGenStreamEvent]:
        """
        Creates an image given a prompt using a GPT Image model.
        [Learn more](https://developers.openai.com/api/docs/guides/images-vision).

        Args:
          prompt: A text description of the desired image(s). The maximum length is 32000
              characters.

          stream: Generate the image in streaming mode. Defaults to `false`. See the
              [Image generation guide](https://developers.openai.com/api/docs/guides/image-generation)
              for more information. This parameter is only supported for the GPT image models.

          background: Allows to set transparency for the background of the generated image(s). Must be
              one of `transparent`, `opaque`, or `auto` (default value). When `auto` is used,
              the model will automatically determine the best background for the image.

              `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
              snapshots, support `opaque` and `transparent` backgrounds. Transparent
              backgrounds are available for supported GPT Image models. For `gpt-image-2` and
              `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
              set the output format to `png` or `webp`.

          complexity: Computation spent planning the image, independently of rendering quality. Uses
              the image model's configured default when omitted. For SVG output, controls the
              reference image, independently of the SVG author's reasoning.

          frame_count: Number of frames for GIF output. Accepts integers from 2 through 16. Defaults to
              9 when omitted. Only supported with output_format=gif. The requested size must
              satisfy the selected model's GIF size limits. GIF output does not support
              streaming, partial images, masks, or custom output compression. Requires access
              to the GIF preview for the selected model.

          frame_duration_ms: Requested delay per GIF frame, in milliseconds. Defaults to 200 when omitted.
              GIF output rounds to the nearest 10 ms and caps the encoded delay at 655,350 ms
              per frame. Only supported with output_format=gif.

          model: The GPT image model to use for image generation. Specify a model explicitly.
              Supported models include `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
              `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
              `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
              `gpt-image-2.5-flare-2026-09-08`, `gpt-image-2.6-sunburst`,
              `gpt-image-2.6-flare`, and `chatgpt-image-latest`.

              `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
              `gpt-image-2.5-flare` instead.

              Deprecated values:

              - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
                gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
              - "dall-e-2", "dall-e-3": This model was retired on May 12, 2026. Use a GPT
                image model instead.

          moderation: Control the content-moderation level for images generated by the GPT image
              models. Must be either `low` for less restrictive filtering or `auto` (default
              value).

          n: The number of images to generate. Must be between 1 and 10.

          output_compression: The compression level (0-100%) for the generated images. This parameter is only
              supported for the GPT image models with the `webp` or `jpeg` output formats, and
              defaults to 100.

          output_format: The format in which the generated images are returned. This parameter is only
              supported for the GPT image models.

          partial_images: The number of partial images to generate. This parameter is used for streaming
              responses that return partial images. Value must be between 0 and 3. When set to
              0, the response will be a single image sent in one streaming event.

              Note that the final image may be sent before the full number of partial images
              are generated if the full image is generated more quickly.

          quality: The quality of the image that will be generated.

              - `auto` (default value) will automatically select the best quality for the
                given model.
              - `high`, `medium` and `low` are supported for the GPT image models.
              - `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their
                `2026-09-08` snapshots, also support `xhigh` and `max`.

              Deprecated values:

              - "standard", "hd": This quality was only supported by retired DALL·E models.
                Use a GPT image quality instead.

          response_format: Legacy response format parameter for retired image models. Unsupported for GPT
              image models, which always return base64-encoded images.

          safety_identifier: A stable identifier for an end user in your organization, used for safety
              monitoring and abuse detection. Hash a username or email address to avoid
              sending identifying information. A non-empty value takes precedence over the
              deprecated `user` parameter. If omitted, null, or empty, the API uses `user`
              when available.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          size: The size of the generated images. For `gpt-image-2`, `gpt-image-2-2026-04-21`,
              `gpt-image-2.5-sunburst`, `gpt-image-2.5-sunburst-2026-09-08`,
              `gpt-image-2.5-flare`, and `gpt-image-2.5-flare-2026-09-08`, arbitrary
              resolutions are supported as `WIDTHxHEIGHT` strings, for example `1536x864`.
              Width and height must both be divisible by 16 and the requested aspect ratio
              must be between 1:3 and 3:1. Resolutions above `2560x1440` are experimental, and
              the maximum supported resolution is `3840x2160`. The requested size must also
              satisfy the model's current pixel and edge limits. The standard sizes
              `1024x1024`, `1536x1024`, and `1024x1536` are supported by the GPT image models;
              `auto` is supported for models that allow automatic sizing.

              Deprecated values:

              - "256x256", "512x512", "1792x1024", "1024x1792": This legacy size suggestion is
                retained for SDK compatibility. Check the selected GPT image model's supported
                sizes.

          style: Legacy style parameter for retired image models. Unsupported for GPT image
              models; describe the desired style in the prompt instead.

          svg: Selects the model and reasoning effort used to author SVG output. Requires
              output_format=svg and access to SVG model selection. When model selection is
              enabled, supply svg.model. When model selection is disabled, omit this object.
              The top-level model selects the image model that creates the reference image.
              SVG generation requires n=1 and does not support streaming, partial images,
              prompt_rewriter, or output_compression. SVG edits are not supported.

          user: Deprecated: use `safety_identifier` instead. This parameter remains accepted for
              backward compatibility and is used when `safety_identifier` is omitted, null, or
              empty.
              [Learn more](https://developers.openai.com/api/docs/guides/safety-best-practices#implement-safety-identifiers).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        ...

    @required_args(["prompt"], ["prompt", "stream"])
    async def generate(
        self,
        *,
        prompt: str,
        background: Optional[Literal["transparent", "opaque", "auto"]] | Omit = omit,
        complexity: Optional[Literal["low", "medium", "high"]] | Omit = omit,
        frame_count: Optional[int] | Omit = omit,
        frame_duration_ms: Optional[int] | Omit = omit,
        model: Union[str, ImageModel, None] | Omit = omit,
        moderation: Optional[Literal["low", "auto"]] | Omit = omit,
        n: Optional[int] | Omit = omit,
        output_compression: Optional[int] | Omit = omit,
        output_format: Optional[Literal["png", "jpeg", "webp", "gif", "svg"]] | Omit = omit,
        partial_images: Optional[int] | Omit = omit,
        quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto", "standard", "hd"]] | Omit = omit,
        response_format: Optional[Literal["url", "b64_json"]] | Omit = omit,
        safety_identifier: Optional[str] | Omit = omit,
        size: Union[
            str,
            Literal["auto", "1024x1024", "1536x1024", "1024x1536", "256x256", "512x512", "1792x1024", "1024x1792"],
            None,
        ]
        | Omit = omit,
        stream: Optional[Literal[False]] | Literal[True] | Omit = omit,
        style: Optional[Literal["vivid", "natural"]] | Omit = omit,
        svg: Optional[image_generate_params.Svg] | Omit = omit,
        user: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx2.Timeout | None | NotGiven = not_given,
    ) -> ImagesResponse | AsyncStream[ImageGenStreamEvent]:
        return await self._post(
            "/images/generations",
            body=await async_maybe_transform(
                {
                    "model": model,
                    "stream": stream,
                    "prompt": prompt,
                    "background": background,
                    "complexity": complexity,
                    "frame_count": frame_count,
                    "frame_duration_ms": frame_duration_ms,
                    "moderation": moderation,
                    "n": n,
                    "output_compression": output_compression,
                    "output_format": output_format,
                    "partial_images": partial_images,
                    "quality": quality,
                    "response_format": response_format,
                    "safety_identifier": safety_identifier,
                    "size": size,
                    "style": style,
                    "svg": svg,
                    "user": user,
                },
                image_generate_params.ImageGenerateParamsStreaming
                if stream
                else image_generate_params.ImageGenerateParamsNonStreaming,
            ),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                security={"bearer_auth": True},
            ),
            cast_to=ImagesResponse,
            stream=stream or False,
            stream_cls=AsyncStream[ImageGenStreamEvent],
        )


class ImagesWithRawResponse:
    def __init__(self, images: Images) -> None:
        self._images = images

        self.create_variation = _legacy_response.to_raw_response_wrapper(
            images.create_variation,
        )
        self.edit = _legacy_response.to_raw_response_wrapper(
            images.edit,
        )
        self.generate = _legacy_response.to_raw_response_wrapper(
            images.generate,
        )


class AsyncImagesWithRawResponse:
    def __init__(self, images: AsyncImages) -> None:
        self._images = images

        self.create_variation = _legacy_response.async_to_raw_response_wrapper(
            images.create_variation,
        )
        self.edit = _legacy_response.async_to_raw_response_wrapper(
            images.edit,
        )
        self.generate = _legacy_response.async_to_raw_response_wrapper(
            images.generate,
        )


class ImagesWithStreamingResponse:
    def __init__(self, images: Images) -> None:
        self._images = images

        self.create_variation = to_streamed_response_wrapper(
            images.create_variation,
        )
        self.edit = to_streamed_response_wrapper(
            images.edit,
        )
        self.generate = to_streamed_response_wrapper(
            images.generate,
        )


class AsyncImagesWithStreamingResponse:
    def __init__(self, images: AsyncImages) -> None:
        self._images = images

        self.create_variation = async_to_streamed_response_wrapper(
            images.create_variation,
        )
        self.edit = async_to_streamed_response_wrapper(
            images.edit,
        )
        self.generate = async_to_streamed_response_wrapper(
            images.generate,
        )
